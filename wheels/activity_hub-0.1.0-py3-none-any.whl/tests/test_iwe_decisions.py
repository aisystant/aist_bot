"""Unit-тесты для transforms/iwe_decisions.py (WP-109 Ф7b).

Контракт parse_decision:
1. Вложенный payload (от capture_writer) → ParsedEvent
2. Плоский payload (упрощённый) → ParsedEvent
3. Неизвестный event_type → None (allowlist)
4. Нет user_utterance → None (schema-filter §4a)
5. Пустой user_utterance → None
6. Все DECISION_EVENT_TYPES проходят allowlist
7. cognitive_weight: из payload или default по типу
8. external_id: session_id + ts (idempotency)
9. external_id без session_id → None
10. occurred_at: парсинг ISO timestamp
11. silver payload: содержит user_utterance, cognitive_weight, session_id
12. Нет session_id → None
"""

import pytest
from datetime import datetime, timezone

from activity_hub.transforms.iwe_decisions import (
    ParsedEvent,
    parse_decision,
    DECISION_EVENT_TYPES,
    _DEFAULT_WEIGHT,
)


# ─────────────────────────── helpers ───────────────────────────

def make_nested(event_type="decision_approve", utterance="Принято, берём вариант A",
                session_id="sess-123", ts="2026-04-13T10:00:00Z",
                cognitive_weight=None) -> dict:
    """Вложенный формат от capture_writer."""
    inner = {
        "session_id": session_id,
        "user_utterance": utterance,
        "cognitive_weight": cognitive_weight or _DEFAULT_WEIGHT.get(event_type, 1),
        "source": "iwe",
        "ts": ts,
        "event_type": event_type,
    }
    return {
        "event_type": event_type,
        "payload": inner,
        "repo_ctx": {"target_repo_hint": "/IWE/DS-my-strategy"},
    }


def make_flat(event_type="decision_approve", utterance="Решение принято",
              session_id="sess-456", ts="2026-04-13T11:00:00Z") -> dict:
    """Плоский формат (уже внутренний payload)."""
    return {
        "event_type": event_type,
        "session_id": session_id,
        "user_utterance": utterance,
        "cognitive_weight": 1,
        "source": "iwe",
        "ts": ts,
    }


# ─────────────────────────── happy path ───────────────────────────

def test_nested_payload_returns_parsed_event():
    result = parse_decision(make_nested())
    assert result is not None
    assert isinstance(result, ParsedEvent)
    assert result.event_type == "decision_approve"
    assert result.user_ref == {"session_id": "sess-123"}
    assert result.confidence == 1.0


def test_flat_payload_returns_parsed_event():
    result = parse_decision(make_flat())
    assert result is not None
    assert result.event_type == "decision_approve"


def test_silver_payload_contains_required_fields():
    result = parse_decision(make_nested(utterance="Выбираем вариант B"))
    assert result is not None
    assert "user_utterance" in result.payload
    assert "cognitive_weight" in result.payload
    assert "session_id" in result.payload
    assert result.payload["user_utterance"] == "Выбираем вариант B"


def test_occurred_at_parsed_from_ts():
    result = parse_decision(make_nested(ts="2026-04-13T10:30:00Z"))
    assert result is not None
    assert result.occurred_at == datetime(2026, 4, 13, 10, 30, 0)
    assert result.occurred_at.tzinfo is None  # UTC naive


def test_external_id_contains_session_and_ts():
    result = parse_decision(make_nested(session_id="my-session", ts="2026-04-13T10:00:00Z"))
    assert result is not None
    assert "my-session" in result.external_id
    assert "2026-04-13T10:00:00Z" in result.external_id


# ─────────────────────────── DECISION_EVENT_TYPES allowlist ───────────────────────────

@pytest.mark.parametrize("event_type", list(DECISION_EVENT_TYPES))
def test_all_allowed_event_types_pass(event_type):
    payload = make_nested(event_type=event_type)
    result = parse_decision(payload)
    assert result is not None
    assert result.event_type == event_type


def test_unknown_event_type_returns_none():
    payload = make_nested(event_type="agent_decision")  # агентское, не пользовательское
    assert parse_decision(payload) is None


def test_empty_event_type_returns_none():
    payload = make_nested(event_type="")
    assert parse_decision(payload) is None


# ─────────────────────────── schema-filter (§4a user_utterance) ───────────────────────────

def test_missing_utterance_returns_none():
    payload = make_nested()
    del payload["payload"]["user_utterance"]
    assert parse_decision(payload) is None


def test_empty_utterance_returns_none():
    payload = make_nested(utterance="")
    assert parse_decision(payload) is None


def test_whitespace_only_utterance_returns_none():
    payload = make_nested(utterance="   ")
    assert parse_decision(payload) is None


# ─────────────────────────── cognitive_weight ───────────────────────────

def test_cognitive_weight_from_payload():
    payload = make_nested(event_type="decision_architectural", cognitive_weight=5)
    result = parse_decision(payload)
    assert result is not None
    assert result.payload["cognitive_weight"] == 5


def test_cognitive_weight_default_for_approve():
    payload = make_nested(event_type="decision_approve")
    result = parse_decision(payload)
    assert result is not None
    assert result.payload["cognitive_weight"] == _DEFAULT_WEIGHT["decision_approve"]


def test_cognitive_weight_default_for_reject():
    payload = make_nested(event_type="decision_reject")
    result = parse_decision(payload)
    assert result is not None
    assert result.payload["cognitive_weight"] == _DEFAULT_WEIGHT["decision_reject"]


# ─────────────────────────── session_id ───────────────────────────

def test_no_session_id_returns_none():
    payload = make_flat(session_id="")
    payload["session_id"] = ""
    assert parse_decision(payload) is None


def test_session_id_in_user_ref():
    result = parse_decision(make_nested(session_id="abc-def"))
    assert result is not None
    assert result.user_ref == {"session_id": "abc-def"}
