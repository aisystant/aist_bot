"""Unit-тесты для core/health_metrics.py.

Контракты:
1. Successful INSERT — conn.execute вызывается с правильным SQL и параметрами.
2. Schema fallback — HEALTH_DB_SCHEMA env переопределяет default 'health'.
3. Best-effort — exception в conn.execute не пропагируется, только log.warning.
4. JSONB сериализация — dict → JSON string в параметрах.
5. None для value_jsonb — null передаётся как None в SQL.
"""

import os
from unittest.mock import AsyncMock, patch

import pytest

from activity_hub.core import health_metrics


@pytest.mark.asyncio
async def test_successful_insert_default_schema():
    """conn.execute вызывается с health.internal_metrics и правильными параметрами."""
    conn = AsyncMock()
    await health_metrics.write_internal_metric(
        conn,
        metric_name="profiler_neon_batch_processed",
        worker="profiler-subscriber-neon",
        value_numeric=42.0,
    )
    conn.execute.assert_awaited_once()
    sql_arg = conn.execute.await_args.args[0]
    assert "health.internal_metrics" in sql_arg
    params = conn.execute.await_args.args[1:]
    assert params == ("profiler_neon_batch_processed", "profiler-subscriber-neon", 42.0, None)


@pytest.mark.asyncio
async def test_schema_override_via_env(monkeypatch):
    """HEALTH_DB_SCHEMA env подменяет 'health' в SQL."""
    monkeypatch.setenv("HEALTH_DB_SCHEMA", "custom_health")
    conn = AsyncMock()
    await health_metrics.write_internal_metric(
        conn,
        metric_name="m",
        worker="w",
        value_numeric=1.0,
    )
    sql_arg = conn.execute.await_args.args[0]
    assert "custom_health.internal_metrics" in sql_arg
    # Не дефолтная схема: ищем точный префикс ' health.' (с пробелом),
    # чтобы не зацепить хвост 'custom_health.'.
    assert " health.internal_metrics" not in sql_arg


@pytest.mark.asyncio
async def test_best_effort_swallows_exception(caplog):
    """Exception в conn.execute не должен пропагироваться (hot-path защита)."""
    conn = AsyncMock()
    conn.execute.side_effect = RuntimeError("conn dead")

    # Не должен бросить, должен залогировать warn
    await health_metrics.write_internal_metric(
        conn,
        metric_name="m",
        worker="w",
        value_numeric=0.0,
    )

    # Проверка лога
    warnings = [r for r in caplog.records if r.levelname == "WARNING"]
    assert any("write failed" in r.message for r in warnings)


@pytest.mark.asyncio
async def test_jsonb_serialization():
    """dict в value_jsonb сериализуется в JSON string."""
    conn = AsyncMock()
    payload = {"errors": 3, "total": 10}
    await health_metrics.write_internal_metric(
        conn,
        metric_name="m",
        worker="w",
        value_numeric=10.0,
        value_jsonb=payload,
    )
    params = conn.execute.await_args.args[1:]
    # Последний параметр — сериализованный JSON
    assert params[3] == '{"errors": 3, "total": 10}'


@pytest.mark.asyncio
async def test_none_jsonb_passes_as_none():
    """value_jsonb=None → params[3]=None (NULL в БД)."""
    conn = AsyncMock()
    await health_metrics.write_internal_metric(
        conn,
        metric_name="m",
        worker="w",
        value_numeric=0.0,
        value_jsonb=None,
    )
    params = conn.execute.await_args.args[1:]
    assert params[3] is None


@pytest.mark.asyncio
async def test_value_numeric_none_allowed():
    """value_numeric=None — допустимо (метрика без числа, только value_jsonb)."""
    conn = AsyncMock()
    await health_metrics.write_internal_metric(
        conn,
        metric_name="m",
        worker="w",
        value_numeric=None,
        value_jsonb={"flag": True},
    )
    params = conn.execute.await_args.args[1:]
    assert params[2] is None
    assert params[3] == '{"flag": true}'
