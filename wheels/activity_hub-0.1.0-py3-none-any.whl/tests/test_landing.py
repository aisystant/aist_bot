"""Unit-тесты для core/landing.py (WP-109 Ф8.3).

Мокаем asyncpg.Connection через FakeConn — имитируем UNIQUE+ON CONFLICT,
чтобы не требовать живой Neon. Тесты закрывают контракт:

1. happy path: валидные items → все inserted
2. idempotency: тот же ext_id+fetched_at → skipped (не insert)
3. битый payload (не JSON-сериализуемый) → failed, не падает
4. пустой external_id → failed, не падает
5. unknown source → ValueError до INSERT
6. пустой список → WriteResult() без обращений к БД
7. INSERT-ошибка БД → failed, цикл продолжается
"""

import json
from datetime import datetime, timezone, timedelta
from typing import Any

import pytest

from activity_hub.core.landing import RawItem, WriteResult, write_raw


class FakeConn:
    """Минимальный stub asyncpg.Connection.

    Имитирует UNIQUE (source, external_id, fetched_at) + ON CONFLICT DO NOTHING:
    ведём in-memory set ключей, повторная вставка = fetchrow возвращает None.
    """

    def __init__(self):
        self._keys: set[tuple] = set()
        self._next_id = 1
        self.fail_next_insert = False  # для теста DB-ошибки

    async def fetchrow(self, query: str, *args: Any):
        # Ожидаем сигнатуру: (source, external_id, payload_json, fetched_at)
        source, external_id, payload_json, fetched_at = args

        if self.fail_next_insert:
            self.fail_next_insert = False
            raise RuntimeError("simulated DB failure")

        # Валидируем что payload — валидный JSON (как делает ::jsonb в проде)
        json.loads(payload_json)

        key = (source, external_id, fetched_at)
        if key in self._keys:
            return None  # ON CONFLICT DO NOTHING
        self._keys.add(key)
        row = {"id": self._next_id}
        self._next_id += 1
        return row


# ─────────────────────────── happy path ───────────────────────────

@pytest.mark.asyncio
async def test_happy_path_three_items_all_inserted():
    conn = FakeConn()
    items = [
        RawItem(external_id="TEXT:1", payload={"action": "TEXT", "actionId": 1}),
        RawItem(external_id="TEXT:2", payload={"action": "TEXT", "actionId": 2}),
        RawItem(external_id="TEST:3", payload={"action": "TEST", "actionId": 3}),
    ]
    result = await write_raw(conn, "lms", items)
    assert result == WriteResult(inserted=3, skipped=0, failed=0)


@pytest.mark.asyncio
async def test_empty_list_returns_zero_result():
    conn = FakeConn()
    result = await write_raw(conn, "lms", [])
    assert result == WriteResult()
    assert conn._keys == set()  # не было обращений


# ─────────────────────────── idempotency ───────────────────────────

@pytest.mark.asyncio
async def test_idempotency_same_items_twice():
    """Повторный прогон того же окна с теми же fetched_at → 0 inserted."""
    conn = FakeConn()
    fixed_time = datetime(2026, 4, 10, 12, 0, tzinfo=timezone.utc)
    items = [
        RawItem(
            external_id="TEXT:1",
            payload={"action": "TEXT", "actionId": 1},
            fetched_at=fixed_time,
        ),
        RawItem(
            external_id="TEXT:2",
            payload={"action": "TEXT", "actionId": 2},
            fetched_at=fixed_time,
        ),
    ]

    first = await write_raw(conn, "lms", items)
    assert first == WriteResult(inserted=2)

    second = await write_raw(conn, "lms", items)
    assert second == WriteResult(inserted=0, skipped=2, failed=0)


@pytest.mark.asyncio
async def test_same_ext_id_different_fetched_at_both_inserted():
    """Та же запись пришла дважды в разное fetched_at — обе попадают в bronze.

    Это invariant bronze: audit trail. Silver (user_events) потом дедуплицирует
    по (source, external_id), но raw_events хранит все снапшоты.
    """
    conn = FakeConn()
    t1 = datetime(2026, 4, 10, 12, 0, tzinfo=timezone.utc)
    t2 = t1 + timedelta(hours=1)
    items = [
        RawItem(external_id="TEXT:1", payload={"action": "TEXT", "actionId": 1}, fetched_at=t1),
        RawItem(external_id="TEXT:1", payload={"action": "TEXT", "actionId": 1}, fetched_at=t2),
    ]
    result = await write_raw(conn, "lms", items)
    assert result == WriteResult(inserted=2)


# ─────────────────────────── resilience ───────────────────────────

@pytest.mark.asyncio
async def test_bad_payload_does_not_crash_pipeline():
    """Не JSON-сериализуемый payload → failed, другие items проходят."""
    conn = FakeConn()

    class Unserializable:
        pass

    items = [
        RawItem(external_id="OK:1", payload={"ok": True}),
        RawItem(external_id="BAD:1", payload={"bad": Unserializable()}),
        RawItem(external_id="OK:2", payload={"ok": True}),
    ]
    result = await write_raw(conn, "lms", items)
    # default=str в json.dumps может спасти — проверяем, что сериализация
    # реально падает на set или complex (set точно не default=str'ится)
    # Переделываем: используем set вместо кастомного класса.
    assert result.inserted + result.failed + result.skipped == 3


@pytest.mark.asyncio
async def test_non_serializable_set_payload_fails_gracefully():
    conn = FakeConn()
    items = [
        RawItem(external_id="OK:1", payload={"ok": True}),
        RawItem(external_id="BAD:1", payload={"bad": {1, 2, 3}}),  # set не сериализуется
        RawItem(external_id="OK:2", payload={"ok": True}),
    ]
    result = await write_raw(conn, "lms", items)
    assert result.inserted == 2
    assert result.failed == 1
    assert result.skipped == 0


@pytest.mark.asyncio
async def test_empty_external_id_is_failed():
    conn = FakeConn()
    items = [
        RawItem(external_id="", payload={"action": "TEXT"}),
        RawItem(external_id="OK:1", payload={"ok": True}),
    ]
    result = await write_raw(conn, "lms", items)
    assert result.inserted == 1
    assert result.failed == 1


@pytest.mark.asyncio
async def test_db_insert_error_is_counted_as_failed():
    conn = FakeConn()
    conn.fail_next_insert = True
    items = [
        RawItem(external_id="FIRST:1", payload={"ok": True}),  # упадёт
        RawItem(external_id="SECOND:1", payload={"ok": True}),  # пройдёт
    ]
    result = await write_raw(conn, "lms", items)
    assert result.inserted == 1
    assert result.failed == 1


# ─────────────────────────── source validation ───────────────────────────

@pytest.mark.asyncio
async def test_unknown_source_raises():
    conn = FakeConn()
    items = [RawItem(external_id="X:1", payload={})]
    with pytest.raises(ValueError, match="Unknown source"):
        await write_raw(conn, "exocortex", items)  # removed from KNOWN_SOURCES


@pytest.mark.asyncio
async def test_known_sources_accepted():
    conn = FakeConn()
    for src in ("lms", "bot", "club", "iwe"):
        items = [RawItem(external_id=f"X:{src}", payload={})]
        result = await write_raw(conn, src, items)
        assert result.inserted == 1
