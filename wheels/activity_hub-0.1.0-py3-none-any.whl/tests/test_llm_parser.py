"""Тесты LLM-парсера — WP-319 Ф4.

Запуск: ANTHROPIC_API_KEY=... .venv/bin/python3 -m pytest tests/test_llm_parser.py -v

10 тест-фраз покрывают: числовые параметры, «перестать делать», сценарии S2/S3,
горизонт времени, неинформативный текст (fallback).
"""
from __future__ import annotations

import asyncio
import pytest


def run(coro):
    return asyncio.run(coro)


# ── тест-кейсы: (текст, ожидаемые условия) ───────────────────────────────────

CASES = [
    # 0: часы/нед → S1, hours_per_week=6
    (
        "начну учиться 6ч/нед",
        {"scenario_id": "s1", "bh_overrides.hours_per_week": 6.0, "high_confidence": True},
    ),
    # 1: дни/нед → S1, days_per_week=5
    (
        "буду заниматься 5 дней в неделю",
        {"scenario_id": "s1", "bh_overrides.days_per_week": 5.0, "high_confidence": True},
    ),
    # 2: закрытие недели → S1, w_delta_per_week > 0 (качественный сигнал — confidence ≥ 0.7)
    (
        "буду закрывать неделю с оценкой 4",
        {"scenario_id": "s1", "bh_overrides.w_delta_per_week": ">0"},
    ),
    # 3: «перестать делать WP» → S1, a_delta_per_week=0 или bh_overrides содержит 0 для WP
    (
        "что если перестать делать рабочие продукты",
        {"scenario_id": "s1", "bh_overrides.a_delta_per_week": 0.0, "high_confidence": True},
    ),
    # 4: уроки + РП → S2
    (
        "буду проходить 2 урока в неделю и закрывать 1 рабочий продукт в месяц",
        {
            "scenario_id": "s2",
            "bh_overrides.lesson_completed_per_week": 2.0,
            "bh_overrides.wp_completed_per_month": 1.0,
            "high_confidence": True,
        },
    ),
    # 5: когорта → S3
    (
        "что будет с первой когортой через 12 недель",
        {"scenario_id": "s3", "high_confidence": True},
    ),
    # 6: горизонт «полгода»
    (
        "начну учиться 8 часов в неделю, посмотрим что будет через полгода",
        {"scenario_id": "s1", "horizon_weeks": 26, "high_confidence": True},
    ),
    # 7: «каждый день» → days_per_week=7
    (
        "начну заниматься каждый день по часу",
        {"scenario_id": "s1", "bh_overrides.days_per_week": 7.0, "high_confidence": True},
    ),
    # 8: Pack + уроки → m_delta > 0 (качественный сигнал — проверяем только наличие override)
    (
        "буду читать Pack и проходить уроки каждую неделю",
        {"scenario_id": "s1", "bh_overrides.m_delta_per_week": ">0"},
    ),
    # 9: неинформативный → fallback
    (
        "привет как дела",
        {"fallback_sliders": True},
    ),
]


@pytest.mark.skipif(
    __import__("os").getenv("ANTHROPIC_API_KEY") is None,
    reason="ANTHROPIC_API_KEY not set",
)
@pytest.mark.parametrize("text,expectations", CASES)
def test_parse_scenario(text, expectations):
    from activity_hub.engines.simulator.llm_parser import parse_scenario_text

    result = run(parse_scenario_text(text))

    for key, expected in expectations.items():
        if key == "high_confidence":
            assert result["confidence"] >= 0.7, (
                f"[{text!r}] confidence={result['confidence']:.2f} < 0.7 (fallback expected=False)"
            )
            assert not result["fallback_sliders"], (
                f"[{text!r}] fallback_sliders=True unexpected"
            )
        elif key == "fallback_sliders":
            assert result["fallback_sliders"] == expected, (
                f"[{text!r}] fallback_sliders={result['fallback_sliders']}, expected={expected}; "
                f"confidence={result['confidence']:.2f}"
            )
        elif key == "scenario_id":
            assert result["scenario_id"] == expected, (
                f"[{text!r}] scenario_id={result['scenario_id']!r}, expected={expected!r}"
            )
        elif key == "horizon_weeks":
            assert result["horizon_weeks"] == expected, (
                f"[{text!r}] horizon_weeks={result['horizon_weeks']}, expected={expected}"
            )
        elif key.startswith("bh_overrides."):
            param = key.split(".", 1)[1]
            overrides = result.get("bh_overrides", {})
            assert param in overrides, (
                f"[{text!r}] bh_overrides missing key {param!r}; got {overrides}"
            )
            val = overrides[param]
            if isinstance(expected, str) and expected.startswith(">"):
                threshold = float(expected[1:])
                assert float(val) > threshold, (
                    f"[{text!r}] bh_overrides[{param!r}]={val} not > {threshold}"
                )
            elif float(expected) == 0.0:
                # «перестать делать X» → строго 0
                assert float(val) == 0.0, (
                    f"[{text!r}] bh_overrides[{param!r}]={val}, expected exactly 0.0"
                )
            else:
                assert abs(float(val) - float(expected)) < 0.5, (
                    f"[{text!r}] bh_overrides[{param!r}]={val}, expected≈{expected}"
                )
