"""Unit-тесты для anonymization_worker.py (WP-214 Ф10.7).

Контракты:
1. _anonymize_account — выполняет все 7 операций (6 DML + 1 audit INSERT).
2. _run_batch — пропускает не-tombstone события, advance cursor по max(id).
3. _run_batch — обрабатывает tombstone с account_id IS NOT NULL.
4. _run_batch — пропускает tombstone с account_id=NULL (уже анонимизирован).
5. Курсор инициализируется в 0 при первом запуске (self-bootstrap).
6. Cursor advance происходит даже при ошибке анонимизации (нет зависания).
"""

from __future__ import annotations

import uuid
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest

from activity_hub.workers import anonymization_worker as aw


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_conn(cursor_val: int = 0) -> AsyncMock:
    """Asyncpg connection mock с preloaded cursor."""
    conn = AsyncMock()
    conn.execute.return_value = "UPDATE 0"
    conn.fetchrow.return_value = {"last_event_id": cursor_val}
    conn.fetchval.return_value = True  # advisory lock = acquired
    # conn.transaction() должен быть SYNC-вызовом, возвращающим async context manager.
    # AsyncMock поддерживает __aenter__/__aexit__ нативно.
    conn.transaction = MagicMock(return_value=AsyncMock())
    return conn


def _make_row(
    row_id: int,
    event_type: str,
    account_id: uuid.UUID | None,
) -> MagicMock:
    row = MagicMock()
    row.__getitem__ = lambda self, key: {
        "id": row_id,
        "event_type": event_type,
        "account_id": account_id,
    }[key]
    return row


# ─────────────────────────────────────────────────────────────────────────────
# Contract 1: _anonymize_account — все 7 операций
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_anonymize_account_all_operations():
    """_anonymize_account вызывает conn.execute ровно 7 раз (6 DML + 1 audit)."""
    conn = AsyncMock()
    # execute возвращает строку с кол-вом затронутых строк
    conn.execute.return_value = "UPDATE 2"

    account_id = uuid.uuid4()
    stats = await aw._anonymize_account(conn, account_id)

    assert conn.execute.await_count == 7

    # Проверяем что все таблицы упомянуты в вызовах
    calls_sql = [str(c) for c in conn.execute.await_args_list]
    tables = [
        "learning.stage_transitions",
        "learning.graduation_log",
        "learning.w_reflections",
        "learning.tracking_consent",
        "club.members",
        "public.domain_event",
        "audit.pii_access_log",
    ]
    for table in tables:
        assert any(table in s for s in calls_sql), f"Missing table in calls: {table}"


@pytest.mark.asyncio
async def test_anonymize_account_stats_keys():
    """_anonymize_account возвращает stats с ключами для каждой операции."""
    conn = AsyncMock()
    conn.execute.return_value = "DELETE 1"
    account_id = uuid.uuid4()

    stats = await aw._anonymize_account(conn, account_id)

    expected_keys = {
        "stage_transitions_nulled",
        "graduation_log_deleted",
        "w_reflections_deleted",
        "tracking_consent_deleted",
        "club_members_deleted",
        "domain_events_nulled",
        "audit_logged",
    }
    assert expected_keys.issubset(stats.keys())
    assert stats["audit_logged"] == 1


@pytest.mark.asyncio
async def test_anonymize_account_passes_account_id():
    """_anonymize_account передаёт account_id как параметр во все DML-запросы."""
    conn = AsyncMock()
    conn.execute.return_value = "UPDATE 0"
    account_id = uuid.UUID("12345678-1234-1234-1234-123456789abc")

    await aw._anonymize_account(conn, account_id)

    # Первый аргумент каждого вызова — SQL, второй — account_id
    for call_args in conn.execute.await_args_list[:-1]:  # последний — audit INSERT с 2 params
        params = call_args.args[1:]
        assert account_id in params, f"account_id not found in call params: {params}"


# ─────────────────────────────────────────────────────────────────────────────
# Contract 2: _run_batch — пропуск не-tombstone
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_batch_skips_non_tombstone():
    """_run_batch не вызывает _anonymize_account для событий, отличных от account_deleted."""
    conn = _make_conn(cursor_val=0)

    non_tombstone_rows = [
        _make_row(1, "lesson_completed", uuid.uuid4()),
        _make_row(2, "day_open", uuid.uuid4()),
        _make_row(3, "club_post_created", uuid.uuid4()),
    ]
    conn.fetch.return_value = non_tombstone_rows

    with patch.object(aw, "_anonymize_account", new_callable=AsyncMock) as mock_anon:
        n = await aw._run_batch(conn)

    mock_anon.assert_not_awaited()
    assert n == 3  # 3 строки в батче, курсор сдвинулся


@pytest.mark.asyncio
async def test_run_batch_advances_cursor_to_max_id():
    """_run_batch сдвигает курсор до max(id) батча, даже если tombstones нет."""
    conn = _make_conn(cursor_val=10)

    rows = [
        _make_row(11, "lesson_completed", uuid.uuid4()),
        _make_row(12, "lesson_completed", uuid.uuid4()),
        _make_row(15, "day_open", uuid.uuid4()),
    ]
    conn.fetch.return_value = rows

    with patch.object(aw, "_advance_cursor", new_callable=AsyncMock) as mock_advance:
        await aw._run_batch(conn)

    mock_advance.assert_awaited_once_with(conn, 15)


# ─────────────────────────────────────────────────────────────────────────────
# Contract 3: _run_batch — обработка tombstone с account_id IS NOT NULL
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_batch_processes_tombstone():
    """_run_batch вызывает _anonymize_account для account_deleted с account_id."""
    conn = _make_conn(cursor_val=0)

    account_id = uuid.uuid4()
    rows = [
        _make_row(1, "lesson_completed", uuid.uuid4()),
        _make_row(2, "account_deleted", account_id),
        _make_row(3, "day_open", uuid.uuid4()),
    ]
    conn.fetch.return_value = rows

    with patch.object(aw, "_anonymize_account", new_callable=AsyncMock) as mock_anon:
        mock_anon.return_value = {"domain_events_nulled": 5, "audit_logged": 1}
        n = await aw._run_batch(conn)

    mock_anon.assert_awaited_once_with(conn, account_id)
    assert n == 3


# ─────────────────────────────────────────────────────────────────────────────
# Contract 4: tombstone с account_id=NULL пропускается (уже анонимизирован)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_batch_skips_already_anonymized_tombstone():
    """account_deleted с account_id=NULL уже обработан — _anonymize_account НЕ вызывается."""
    conn = _make_conn(cursor_val=0)

    rows = [
        _make_row(1, "account_deleted", None),  # уже анонимизирован
    ]
    conn.fetch.return_value = rows

    with patch.object(aw, "_anonymize_account", new_callable=AsyncMock) as mock_anon:
        n = await aw._run_batch(conn)

    mock_anon.assert_not_awaited()
    assert n == 1  # строка прочитана, курсор сдвинулся


# ─────────────────────────────────────────────────────────────────────────────
# Contract 5: self-bootstrap cursor
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_get_or_init_cursor_returns_zero_on_first_run():
    """_get_or_init_cursor возвращает 0 при первом запуске (нет строки в таблице)."""
    conn = AsyncMock()
    conn.execute.return_value = None
    conn.fetchrow.return_value = None  # строки нет

    result = await aw._get_or_init_cursor(conn)

    assert result == 0
    # Должен был выполнить CREATE TABLE IF NOT EXISTS + INSERT ... ON CONFLICT
    assert conn.execute.await_count >= 2


@pytest.mark.asyncio
async def test_get_or_init_cursor_returns_existing_value():
    """_get_or_init_cursor возвращает сохранённый cursor если уже инициализирован."""
    conn = AsyncMock()
    conn.execute.return_value = None
    conn.fetchrow.return_value = {"last_event_id": 42}

    result = await aw._get_or_init_cursor(conn)

    assert result == 42


# ─────────────────────────────────────────────────────────────────────────────
# Contract 6: cursor advance даже при ошибке анонимизации
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_run_batch_advances_cursor_on_anonymization_error():
    """При ошибке _anonymize_account курсор всё равно сдвигается (нет зависания)."""
    conn = _make_conn(cursor_val=0)

    account_id = uuid.uuid4()
    rows = [_make_row(5, "account_deleted", account_id)]
    conn.fetch.return_value = rows

    with patch.object(aw, "_anonymize_account", new_callable=AsyncMock) as mock_anon:
        mock_anon.side_effect = RuntimeError("DB error")
        with patch.object(aw, "_advance_cursor", new_callable=AsyncMock) as mock_advance:
            n = await aw._run_batch(conn)

    # Cursor должен сдвинуться до 5 несмотря на ошибку
    mock_advance.assert_awaited_once_with(conn, 5)
    assert n == 1
