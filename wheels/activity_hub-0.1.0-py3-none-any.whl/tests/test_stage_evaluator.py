"""Unit-тесты для stage_evaluator.py (WP-310 Ф10, FORM.089 v4 §12.2-12.3).

Контракты:
1. compute_stage_mvp — FORM.089 §12.3: матрица STAGE_GATE_MATRIX + hard gates.
2. К4 fix: t_idx вычисляется БЕЗ coding_time (только slot_logged + lesson_completed).
3. bh.stb: calc_stb возвращает norm_stb(max_gap_days).
4. evaluate_one — INSERT при computed > cur, noop при computed <= cur, dry_run нет записи.

NOTE: тесты переписаны в WP-310 Ф10 — старый API (compute_stage + _idx)
заменён на compute_stage_mvp (s, t, m, w, a, total_hours, stb).
"""
from __future__ import annotations

import datetime
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from activity_hub.core.stage_config import (
    compute_stage_mvp,
    CUMULATIVE_HOURS_GATE,
    STB_GATE,
    norm_stb,
)
from activity_hub.workers import stage_evaluator as se


# ─────────────────────────────────────────────────────────────────────────────
# compute_stage_mvp — FORM.089 §12.3
# ─────────────────────────────────────────────────────────────────────────────

def test_compute_stage_mvp_mandatory_gate_s_zero():
    """s==0 → ступень 1 независимо от остальных индексов."""
    assert compute_stage_mvp(s=0, t=5, m=5, w=5, a=5, total_hours=200.0, stb=5) == 1


def test_compute_stage_mvp_mandatory_gate_t_zero():
    """t==0 → ступень 1 независимо от остальных индексов."""
    assert compute_stage_mvp(s=5, t=0, m=5, w=5, a=5, total_hours=200.0, stb=5) == 1


def test_compute_stage_mvp_stage_2_basic():
    """Минимальные условия для ступени 2: s≥2, t≥2, m≥0, w≥0, a≥0."""
    # total_hours >= CUMULATIVE_HOURS_GATE[2] = 20.0
    result = compute_stage_mvp(s=2, t=2, m=0, w=0, a=0, total_hours=20.0, stb=5)
    assert result == 2


def test_compute_stage_mvp_stage_2_hours_gate_blocks():
    """total_hours < 20 при s=2, t=2 → понижение до ступени 1."""
    result = compute_stage_mvp(s=2, t=2, m=0, w=0, a=0, total_hours=10.0, stb=5)
    assert result == 1


def test_compute_stage_mvp_stage_3():
    """s≥3, t≥3, m≥1, w≥2, a≥1 + total_hours≥48 → ступень 3."""
    result = compute_stage_mvp(s=3, t=3, m=1, w=2, a=1, total_hours=50.0, stb=5)
    assert result == 3


def test_compute_stage_mvp_stage_4():
    """s≥4, t≥4, m≥2, w≥3, a≥2 + total_hours≥96 → ступень 4."""
    result = compute_stage_mvp(s=4, t=4, m=2, w=3, a=2, total_hours=100.0, stb=5)
    assert result == 4


def test_compute_stage_mvp_stage_5():
    """Все индексы 5 + total_hours≥161 → ступень 5."""
    result = compute_stage_mvp(s=5, t=5, m=4, w=4, a=4, total_hours=170.0, stb=5)
    assert result == 5


def test_compute_stage_mvp_stb_gate_blocks():
    """stb < STB_GATE[3]=2 → понижение ступени 3 → 2."""
    # stb=1 < STB_GATE[3]=2 → понижаем до 2
    # stb=1 >= STB_GATE[2]=1 → остаётся на 2
    result = compute_stage_mvp(s=3, t=3, m=1, w=2, a=1, total_hours=50.0, stb=1)
    assert result == 2


def test_compute_stage_mvp_stb_gate_default_passes():
    """stb=5 (default) — не блокирует ни одну ступень."""
    result = compute_stage_mvp(s=3, t=3, m=1, w=2, a=1, total_hours=50.0)
    assert result == 3


def test_compute_stage_mvp_all_zero_falls_to_1():
    """s=1, t=1, m=0, w=0, a=0 + нет hours → ступень 1 (mandatory gate не срабатывает, матрица 2 не проходит)."""
    result = compute_stage_mvp(s=1, t=1, m=0, w=0, a=0, total_hours=0.0, stb=5)
    assert result == 1


# ─────────────────────────────────────────────────────────────────────────────
# norm_stb — нормализация bh.stb
# ─────────────────────────────────────────────────────────────────────────────

def test_norm_stb_zero_days():
    """0 дней разрыва → индекс 5 (идеально)."""
    assert norm_stb(0) == 5


def test_norm_stb_one_day():
    """1 день разрыва → индекс 5."""
    assert norm_stb(1) == 5


def test_norm_stb_three_days():
    """3 дня → индекс 4."""
    assert norm_stb(3) == 4


def test_norm_stb_seven_days():
    """7 дней → индекс 3."""
    assert norm_stb(7) == 3


def test_norm_stb_fourteen_days():
    """14 дней → индекс 2."""
    assert norm_stb(14) == 2


def test_norm_stb_thirty_days():
    """30 дней → индекс 1."""
    assert norm_stb(30) == 1


def test_norm_stb_over_thirty():
    """31+ дней → индекс 0."""
    assert norm_stb(31) == 0
    assert norm_stb(100) == 0


# ─────────────────────────────────────────────────────────────────────────────
# calc_stb — SQL → stb_idx
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_calc_stb_no_events():
    """Нет событий → max_gap_days=0 → stb_idx=5."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={"max_gap_days": 0, "event_count": 0})
    stb_idx, detail = await se.calc_stb(conn, "test-uuid")
    assert stb_idx == 5
    assert detail["max_gap_days"] == 0
    assert detail["self_dev_event_count"] == 0


@pytest.mark.asyncio
async def test_calc_stb_large_gap():
    """max_gap_days=35 → stb_idx=0 (>30 дней)."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={"max_gap_days": 35, "event_count": 10})
    stb_idx, detail = await se.calc_stb(conn, "test-uuid")
    assert stb_idx == 0
    assert detail["max_gap_days"] == 35
    assert detail["self_dev_event_count"] == 10


@pytest.mark.asyncio
async def test_calc_stb_small_gap():
    """max_gap_days=2 → stb_idx=4."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={"max_gap_days": 2, "event_count": 25})
    stb_idx, detail = await se.calc_stb(conn, "test-uuid")
    assert stb_idx == 4


# ─────────────────────────────────────────────────────────────────────────────
# К4 fix: calc_t не использует coding_time в t_idx
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_calc_t_k4_no_coding_time_in_t_idx():
    """К4: coding_time НЕ влияет на t_idx. slot=0, lesson=0 → t_idx=0 даже при высоком ct."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={
        # ct большой (WakaTime — всё время)
        "ct_1w": 100.0, "ct_4w": 400.0, "ct_8w": 800.0, "ct_12w": 1200.0, "ct_24w": 2400.0,
        # slot_logged = 0
        "sl_1w": 0.0, "sl_4w": 0.0, "sl_8w": 0.0, "sl_12w": 0.0, "sl_24w": 0.0,
        # lesson_completed = 0
        "lc_1w": 0.0, "lc_4w": 0.0, "lc_8w": 0.0, "lc_12w": 0.0, "lc_24w": 0.0,
        # Option A: source-разбивка (нет активных, нет self_report)
        "sl_active_4w": 0.0, "sl_selfrep_4w": 0.0,
    })
    t_idx, detail = await se.calc_t(conn, "test-uuid")
    # К4: t_idx должен быть 0 (slot+lesson = 0)
    assert t_idx == 0
    # coding_time_hpw должен быть в detail (информационно)
    assert "coding_time_hpw" in detail
    assert detail["coding_time_hpw"][4] > 0  # ct_4w=400.0 / 4 = 100 ч/нед


@pytest.mark.asyncio
async def test_calc_t_k4_slot_only_gives_idx():
    """К4: slot_logged достаточно для t_idx≥1 (0.5 ч/нед за 1 нед)."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={
        "ct_1w": 0.0, "ct_4w": 0.0, "ct_8w": 0.0, "ct_12w": 0.0, "ct_24w": 0.0,
        "sl_1w": 1.0,  # 1 ч за 1 нед → T_THRESHOLDS[1][2]=0.5 → idx=1
        "sl_4w": 0.0, "sl_8w": 0.0, "sl_12w": 0.0, "sl_24w": 0.0,
        "lc_1w": 0.0, "lc_4w": 0.0, "lc_8w": 0.0, "lc_12w": 0.0, "lc_24w": 0.0,
        "sl_active_4w": 0.0, "sl_selfrep_4w": 0.0,
    })
    t_idx, detail = await se.calc_t(conn, "test-uuid")
    assert t_idx >= 1


@pytest.mark.asyncio
async def test_calc_t_self_reported_contributes_to_t_idx():
    """Ф13a Option A: slot_logged (source=self_report_backfill, 20ч за 4 нед) → t_idx≥2.

    Self-report хранится как slot_logged с payload.source='self_report_*'.
    sl_4w включает эти часы → total_hpw[4] = 20/4 = 5.0 ч/нед → t_idx≥2.
    """
    conn = AsyncMock()
    # 20ч за 4 нед в slot_logged (self_report_backfill source)
    conn.fetchrow = AsyncMock(return_value={
        "ct_1w": 0.0, "ct_4w": 0.0, "ct_8w": 0.0, "ct_12w": 0.0, "ct_24w": 0.0,
        "sl_1w": 0.0, "sl_4w": 20.0, "sl_8w": 0.0, "sl_12w": 0.0, "sl_24w": 0.0,
        "lc_1w": 0.0, "lc_4w": 0.0, "lc_8w": 0.0, "lc_12w": 0.0, "lc_24w": 0.0,
        "sl_active_4w": 0.0, "sl_selfrep_4w": 20.0,  # все 20ч — self_report
    })
    t_idx, detail = await se.calc_t(conn, "test-uuid")
    # total_hpw[4] = 20.0 / 4 = 5.0 ч/нед → t_idx≥2
    assert detail["hours_per_week"][4] >= 5.0
    assert t_idx >= 2
    # Option A: source-разбивка в detail (прозрачность)
    assert "sl_selfrep_4w_hpw" in detail
    assert detail["sl_selfrep_4w_hpw"] >= 5.0

@pytest.mark.asyncio
async def test_calc_total_hours_k4_no_coding_time():
    """К4: calc_total_hours возвращает только sl+lc (coding_time и time_self_reported исключены)."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={"sl": 10.0, "lc": 5.0})
    total = await se.calc_total_hours(conn, "test-uuid")
    assert total == 15.0


# ─────────────────────────────────────────────────────────────────────────────
# evaluate_one — integration с mock'ом conn
# ─────────────────────────────────────────────────────────────────────────────

def _make_conn_mock(cur_stage: int = 0) -> AsyncMock:
    """Создаёт mock conn для evaluate_one с минимальными данными → computed=1."""
    conn = AsyncMock()

    # Имитируем все fetchrow/fetch/fetchval вызовы в нужном порядке.
    # Порядок: cur_row, calc_s, calc_t, calc_m (fetch), calc_w (fetch), calc_a (fetch),
    #           calc_total_hours, calc_stb

    # calc_s — fetchrow
    s_row = {
        "days_1w": 0, "days_4w": 0, "days_8w": 0, "days_12w": 0, "days_24w": 0,
    }
    # calc_t — fetchrow (Option A: sl_active_4w + sl_selfrep_4w вместо sr_*)
    t_row = {
        "ct_1w": 0.0, "ct_4w": 0.0, "ct_8w": 0.0, "ct_12w": 0.0, "ct_24w": 0.0,
        "sl_1w": 1.0, "sl_4w": 0.0, "sl_8w": 0.0, "sl_12w": 0.0, "sl_24w": 0.0,
        "lc_1w": 0.0, "lc_4w": 0.0, "lc_8w": 0.0, "lc_12w": 0.0, "lc_24w": 0.0,
        "sl_active_4w": 0.0, "sl_selfrep_4w": 0.0,
    }
    # calc_total_hours — fetchrow (Option A: только sl+lc)
    hours_row = {"sl": 5.0, "lc": 0.0}
    # calc_stb — fetchrow
    stb_row = {"max_gap_days": 0, "event_count": 1}

    conn.fetchrow = AsyncMock(side_effect=[
        {"cur": cur_stage},  # cur_row
        s_row,               # calc_s
        t_row,               # calc_t
        hours_row,           # calc_total_hours
        stb_row,             # calc_stb
    ])

    # calc_m, calc_w, calc_a используют fetch (не fetchrow)
    conn.fetch = AsyncMock(side_effect=[
        [],  # calc_m — нет событий
        [],  # calc_w — нет событий
        [],  # calc_a — нет событий
    ])

    conn.execute = AsyncMock(return_value="INSERT 0 1")
    return conn


@pytest.mark.asyncio
async def test_evaluate_one_inserts_first_transition():
    """Пилот без transitions, computed=1 → INSERT 0→1 (manual_calibration)."""
    conn = _make_conn_mock(cur_stage=0)
    result = await se.evaluate_one(conn, "25d91dbb-6ea2-46a7-a3da-cc1fd9dc9340")

    assert result["action"] == "insert"
    assert result["from"] == 0
    assert result["to"] == 1
    assert result["triggered_by"] == "manual_calibration"
    # INSERT было вызвано
    insert_calls = [c for c in conn.execute.call_args_list if "INSERT" in str(c)]
    assert len(insert_calls) == 1


@pytest.mark.asyncio
async def test_evaluate_one_noop_when_computed_not_higher():
    """Пилот уже на ст. 2, computed=1 → noop (нет INSERT)."""
    conn = _make_conn_mock(cur_stage=2)
    result = await se.evaluate_one(conn, "25d91dbb-6ea2-46a7-a3da-cc1fd9dc9340")

    assert result["action"] == "noop"
    assert result["cur"] == 2
    assert result["computed"] == 1
    # Никакого INSERT
    insert_calls = [c for c in conn.execute.call_args_list if "INSERT" in str(c)]
    assert len(insert_calls) == 0


@pytest.mark.asyncio
async def test_evaluate_one_dry_run_does_not_insert():
    """dry_run=True → would_insert action, БД не трогается."""
    conn = _make_conn_mock(cur_stage=0)
    result = await se.evaluate_one(conn, "25d91dbb-6ea2-46a7-a3da-cc1fd9dc9340", dry_run=True)

    assert result["action"] == "would_insert"
    assert result["to"] == 1
    # БД не трогали
    conn.execute.assert_not_called()


@pytest.mark.asyncio
async def test_evaluate_one_evidence_includes_stb():
    """evidence в dry_run содержит stb и max_gap_days."""
    conn = _make_conn_mock(cur_stage=0)
    result = await se.evaluate_one(conn, "25d91dbb-6ea2-46a7-a3da-cc1fd9dc9340", dry_run=True)

    evidence = result["evidence"]
    assert "stb" in evidence
    assert "max_gap_days" in evidence
    assert isinstance(evidence["stb"], int)
    assert isinstance(evidence["max_gap_days"], int)


@pytest.mark.asyncio
async def test_evaluate_one_evidence_includes_coding_time_informational():
    """evidence содержит t_with_coding_time_hpw_4w (информационно, не блокирует)."""
    conn = _make_conn_mock(cur_stage=0)
    result = await se.evaluate_one(conn, "25d91dbb-6ea2-46a7-a3da-cc1fd9dc9340", dry_run=True)

    evidence = result["evidence"]
    assert "t_with_coding_time_hpw_4w" in evidence


# ─────────────────────────────────────────────────────────────────────────────
# Ф13a Option A: slot_logged+source (не time_self_reported event_type)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_calc_t_source_breakdown_in_detail():
    """Option A: sl_active_4w_hpw и sl_selfrep_4w_hpw присутствуют в detail."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={
        "ct_1w": 0.0, "ct_4w": 0.0, "ct_8w": 0.0, "ct_12w": 0.0, "ct_24w": 0.0,
        "sl_1w": 0.0, "sl_4w": 0.0, "sl_8w": 0.0, "sl_12w": 0.0, "sl_24w": 0.0,
        "lc_1w": 0.0, "lc_4w": 0.0, "lc_8w": 0.0, "lc_12w": 0.0, "lc_24w": 0.0,
        "sl_active_4w": 0.0, "sl_selfrep_4w": 0.0,
    })
    _t_idx, detail = await se.calc_t(conn, "test-uuid")
    assert "sl_active_4w_hpw" in detail
    assert "sl_selfrep_4w_hpw" in detail


@pytest.mark.asyncio
async def test_calc_t_selfrep_zero_does_not_affect_slot_calc():
    """Option A: если self_report = 0 (sl_selfrep_4w=0), slot_logged активный даёт t_idx≥1."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={
        "ct_1w": 0.0, "ct_4w": 0.0, "ct_8w": 0.0, "ct_12w": 0.0, "ct_24w": 0.0,
        "sl_1w": 1.0, "sl_4w": 0.0, "sl_8w": 0.0, "sl_12w": 0.0, "sl_24w": 0.0,
        "lc_1w": 0.0, "lc_4w": 0.0, "lc_8w": 0.0, "lc_12w": 0.0, "lc_24w": 0.0,
        "sl_active_4w": 0.0, "sl_selfrep_4w": 0.0,
    })
    t_idx, detail = await se.calc_t(conn, "test-uuid")
    assert t_idx >= 1
    assert detail["sl_selfrep_4w_hpw"] == 0.0


@pytest.mark.asyncio
async def test_calc_total_hours_slot_includes_selfrep():
    """Option A: slot_logged включает self_report source — total_hours = sl + lc."""
    conn = AsyncMock()
    # sl=18 (10 active + 8 self_report_backfill), lc=5
    conn.fetchrow = AsyncMock(return_value={"sl": 18.0, "lc": 5.0})
    total = await se.calc_total_hours(conn, "test-uuid")
    assert total == 23.0


@pytest.mark.asyncio
async def test_calc_total_hours_selfrep_only_via_slot():
    """Option A: только slot_logged с self_report source → total_hours > 0."""
    conn = AsyncMock()
    conn.fetchrow = AsyncMock(return_value={"sl": 15.0, "lc": 0.0})
    total = await se.calc_total_hours(conn, "test-uuid")
    assert total == 15.0
