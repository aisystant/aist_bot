"""Unit-тесты для transforms/lms.py и core/transform.py (WP-109 Ф8.4).

Тестируем контракт transform без живой БД:

transforms/lms.py:
  1. happy path: валидный bulk payload → ParsedEvent
  2. happy path: per-user payload (без email) → ParsedEvent
  3. timestamp форматы: timezone name, обрезанный offset, нестандартные дробные
  4. ACTION_TYPE_MAP: известный тип → event_type, неизвестный → lowercase
  5. нет action поля → None
  6. нет datetime поля → None
  7. нет user identity (нет email, нет userId) → None
  8. external_id: с actionId и без
  9. silver payload: технические поля убраны (action/actionId/datetime/email/userId)

core/transform.py:
  10. run_transform dry_run: ParsedEvent создаётся, БД не трогается
  11. idempotency: повторный прогон тех же raw → skipped, не done
  12. parse failure → status='failed', pipeline не падает
  13. user_not_found → status='failed', pipeline не падает
"""

import json
from datetime import datetime, timezone
from typing import Any, Optional
from uuid import UUID

import pytest

from activity_hub.transforms.lms import (
    ParsedEvent,
    _parse_timestamp,
    parse_action,
    ACTION_TYPE_MAP,
)
from activity_hub.core.transform import (
    TransformResult,
    _transform_source,
)


# ─────────────────────────── parse_action: happy path ───────────────────────────

def test_bulk_payload_full_fields():
    """Bulk endpoint: userId + email → ParsedEvent с обоими в user_ref."""
    payload = {
        "action": "TEXT",
        "actionId": 42,
        "datetime": "2026-04-10T10:00:00",
        "userId": 123,
        "email": "user@example.com",
        "sectionId": 7,
        "courseId": 3,
    }
    result = parse_action(payload)
    assert result is not None
    assert result.event_type == "text_submitted"
    assert result.external_id == "TEXT:42"
    assert result.user_ref == {"email": "user@example.com", "lms_user_id": 123}
    assert result.occurred_at == datetime(2026, 4, 10, 10, 0, 0)
    assert result.payload == {"sectionId": 7, "courseId": 3}
    assert result.confidence == 0.9


def test_per_user_payload_no_email():
    """Per-user endpoint: нет email → user_ref только с lms_user_id."""
    payload = {
        "action": "TEST",
        "actionId": 99,
        "datetime": "2026-04-10T12:00:00",
        "userId": 456,
    }
    result = parse_action(payload)
    assert result is not None
    assert result.event_type == "test_passed"
    assert result.user_ref == {"lms_user_id": 456}


def test_no_action_id_uses_datetime_as_external_id():
    """Без actionId dedup-ключ = action:datetime."""
    payload = {
        "action": "POMODORO",
        "datetime": "2026-04-10T15:30:00",
        "userId": 1,
    }
    result = parse_action(payload)
    assert result is not None
    assert result.external_id == "POMODORO:2026-04-10T15:30:00"


def test_silver_payload_removes_technical_fields():
    """action/actionId/datetime/email/userId убираются из silver payload."""
    payload = {
        "action": "TASK",
        "actionId": 10,
        "datetime": "2026-04-10T09:00:00",
        "userId": 1,
        "email": "x@x.com",
        "sectionId": 5,
        "score": 95,
    }
    result = parse_action(payload)
    assert result is not None
    assert "action" not in result.payload
    assert "actionId" not in result.payload
    assert "datetime" not in result.payload
    assert "email" not in result.payload
    assert "userId" not in result.payload
    assert result.payload == {"sectionId": 5, "score": 95}


# ─────────────────────────── ACTION_TYPE_MAP ───────────────────────────

@pytest.mark.parametrize("action,expected", list(ACTION_TYPE_MAP.items()))
def test_known_action_types_mapped(action, expected):
    payload = {
        "action": action,
        "actionId": 1,
        "datetime": "2026-04-10T10:00:00",
        "userId": 1,
    }
    result = parse_action(payload)
    assert result is not None
    assert result.event_type == expected


def test_unknown_action_type_lowercased():
    """Неизвестный тип → lowercase (не падает)."""
    payload = {
        "action": "CUSTOM_ACTION",
        "actionId": 1,
        "datetime": "2026-04-10T10:00:00",
        "userId": 1,
    }
    result = parse_action(payload)
    assert result is not None
    assert result.event_type == "custom_action"


# ─────────────────────────── timestamp парсинг ───────────────────────────

def test_timestamp_with_timezone_name():
    """'2026-04-02T23:59:02.58+05:00[Asia/Yekaterinburg]' → UTC naive."""
    dt = _parse_timestamp("2026-04-02T23:59:02.58+05:00[Asia/Yekaterinburg]")
    assert dt is not None
    # 23:59:02 +05:00 → 18:59:02 UTC
    assert dt == datetime(2026, 4, 2, 18, 59, 2, 580000)
    assert dt.tzinfo is None  # UTC naive


def test_timestamp_truncated_offset():
    """'+05:' → '+05:00'."""
    dt = _parse_timestamp("2026-04-02T10:00:00+05:")
    assert dt is not None
    assert dt == datetime(2026, 4, 2, 5, 0, 0)


def test_timestamp_nonstandard_fractional():
    """'2026-04-02T10:00:00.44545' → нормализуется до 6 знаков."""
    dt = _parse_timestamp("2026-04-02T10:00:00.44545")
    assert dt is not None
    assert dt.microsecond == 445450


def test_timestamp_plain_naive():
    """Простой ISO без timezone."""
    dt = _parse_timestamp("2026-04-10T10:00:00")
    assert dt == datetime(2026, 4, 10, 10, 0, 0)


def test_timestamp_invalid_returns_none():
    dt = _parse_timestamp("not-a-date")
    assert dt is None


# ─────────────────────────── parse_action: validation ───────────────────────────

def test_missing_action_returns_none():
    payload = {"datetime": "2026-04-10T10:00:00", "userId": 1}
    assert parse_action(payload) is None


def test_missing_datetime_returns_none():
    payload = {"action": "TEXT", "actionId": 1, "userId": 1}
    assert parse_action(payload) is None


def test_no_user_identity_returns_none():
    """Нет ни email, ни userId → None (нельзя резолвить user)."""
    payload = {
        "action": "TEXT",
        "actionId": 1,
        "datetime": "2026-04-10T10:00:00",
        # нет userId, нет email
    }
    assert parse_action(payload) is None


def test_invalid_timestamp_returns_none():
    payload = {
        "action": "TEXT",
        "actionId": 1,
        "datetime": "not-a-date",
        "userId": 1,
    }
    assert parse_action(payload) is None


# ─────────────────────────── core/transform.py ───────────────────────────

class FakePool:
    """Минимальный stub asyncpg.Pool для тестирования transform-worker.

    Хранит состояние raw_events и user_events in-memory. Имитирует:
    - fetch() для raw_events (pending rows)
    - fetchrow() для INSERT user_events ON CONFLICT DO NOTHING
    - execute() для UPDATE raw_events transform_status
    - resolve_user_uuid (через monkey-patching в тестах)
    """

    def __init__(self, pending_rows: list[dict]):
        # pending_rows: list of {'id': int, 'payload': dict}
        self._pending = list(pending_rows)
        self._user_events: set[tuple] = set()  # (source, external_id)
        self._raw_statuses: dict[int, str] = {}  # raw_id → status
        self._acquire_conn = FakeConn(self)

    def acquire(self):
        return _FakeAcquireContext(self._acquire_conn)


class _FakeAcquireContext:
    def __init__(self, conn):
        self._conn = conn

    async def __aenter__(self):
        return self._conn

    async def __aexit__(self, *args):
        pass


class FakeConn:
    def __init__(self, pool: FakePool):
        self._pool = pool

    async def fetch(self, query: str, *args: Any):
        # Возвращаем pending строки (упрощённо: все, без фильтра по source/limit)
        return [_FakeRecord(r) for r in self._pool._pending]

    async def fetchrow(self, query: str, *args: Any):
        # INSERT user_events ... RETURNING id
        # args[7] = external_id (8-й параметр)
        source = args[3] if len(args) > 3 else "lms"
        external_id = args[7] if len(args) > 7 else None
        if external_id is None:
            return None
        key = (source, external_id)
        if key in self._pool._user_events:
            return None  # dedup
        self._pool._user_events.add(key)
        return {"id": len(self._pool._user_events)}

    async def execute(self, query: str, *args: Any):
        # Два случая UPDATE raw_events:
        # _upsert_event: UPDATE ... SET transform_status = 'done' WHERE id = $1 → args=(raw_id,)
        # _mark:         UPDATE ... SET transform_status = $1, transform_error = $2 WHERE id = $3 → args=(status, error, raw_id)
        if "transform_status" in query:
            if len(args) == 1:
                # _upsert_event: статус зашит в SQL как 'done'
                raw_id = args[0]
                self._pool._raw_statuses[raw_id] = "done"
            elif len(args) >= 3:
                # _mark: статус передаётся параметром
                status = args[0]
                raw_id = args[2]
                self._pool._raw_statuses[raw_id] = status

    def transaction(self):
        return _FakeTxContext(self)


class _FakeTxContext:
    def __init__(self, conn):
        self._conn = conn

    async def __aenter__(self):
        return self._conn

    async def __aexit__(self, *args):
        pass


class _FakeRecord:
    """Имитирует asyncpg.Record — доступ по ключу и как dict."""

    def __init__(self, data: dict):
        self._data = data

    def __getitem__(self, key):
        return self._data[key]

    def __contains__(self, key):
        return key in self._data

    def get(self, key, default=None):
        return self._data.get(key, default)

    def keys(self):
        return self._data.keys()


# monkey-patch resolve_user_uuid для тестов transform.
# Патчим В модуле transform (не в identity), потому что transform импортирует
# функцию через `from ... import resolve_user_uuid` — нужно заменить именно
# тот объект, который уже привязан в пространстве имён transform.
import activity_hub.core.transform as transform_module
import activity_hub.core.identity as identity_module


@pytest.mark.asyncio
async def test_transform_dry_run_no_writes(monkeypatch):
    """dry_run=True: ParsedEvent создаётся, никаких UPDATE/INSERT не происходит."""
    async def fake_resolve(conn, user_ref):
        return UUID("00000000-0000-0000-0000-000000000001")

    monkeypatch.setattr(transform_module, "resolve_user_uuid", fake_resolve)

    payload = {
        "action": "TEXT",
        "actionId": 1,
        "datetime": "2026-04-10T10:00:00",
        "userId": 1,
        "email": "x@x.com",
    }
    pool = FakePool([{"id": 1, "payload": payload}])

    result = await _transform_source(pool, "lms", limit=100, dry_run=True)

    assert result.dry_run is True
    assert result.processed == 1
    assert result.done == 1
    assert result.failed == 0
    # dry_run → никаких записей в raw_statuses
    assert pool._raw_statuses == {}


@pytest.mark.asyncio
async def test_transform_happy_path(monkeypatch):
    """Успешный прогон: 2 строки → 2 done, статусы 'done'."""
    async def fake_resolve(conn, user_ref):
        return UUID("00000000-0000-0000-0000-000000000001")

    monkeypatch.setattr(transform_module, "resolve_user_uuid", fake_resolve)

    payloads = [
        {"action": "TEXT", "actionId": 1, "datetime": "2026-04-10T10:00:00", "userId": 1},
        {"action": "TEST", "actionId": 2, "datetime": "2026-04-10T11:00:00", "userId": 1},
    ]
    pool = FakePool([{"id": i + 1, "payload": p} for i, p in enumerate(payloads)])

    result = await _transform_source(pool, "lms", limit=100, dry_run=False)

    assert result.processed == 2
    assert result.done == 2
    assert result.failed == 0
    assert result.skipped == 0
    assert pool._raw_statuses == {1: "done", 2: "done"}


@pytest.mark.asyncio
async def test_transform_idempotency(monkeypatch):
    """Повторный прогон тех же строк → skipped (dedup), не done."""
    async def fake_resolve(conn, user_ref):
        return UUID("00000000-0000-0000-0000-000000000001")

    monkeypatch.setattr(transform_module, "resolve_user_uuid", fake_resolve)

    payload = {"action": "TEXT", "actionId": 1, "datetime": "2026-04-10T10:00:00", "userId": 1}
    pool = FakePool([{"id": 1, "payload": payload}])

    # Первый прогон
    r1 = await _transform_source(pool, "lms", limit=100, dry_run=False)
    assert r1.done == 1
    assert r1.skipped == 0

    # Добавить ту же строку снова (как если бы status не сменился — имитируем pending)
    pool._pending = [{"id": 1, "payload": payload}]

    # Второй прогон — (source, external_id) уже в user_events → skipped
    r2 = await _transform_source(pool, "lms", limit=100, dry_run=False)
    assert r2.skipped == 1
    assert r2.done == 0


@pytest.mark.asyncio
async def test_transform_parse_failure_marked_failed(monkeypatch):
    """Невалидный payload → status='failed', pipeline не падает."""
    async def fake_resolve(conn, user_ref):
        return UUID("00000000-0000-0000-0000-000000000001")

    monkeypatch.setattr(transform_module, "resolve_user_uuid", fake_resolve)

    bad_payload = {"not_action": "X"}  # нет поля action → parse_action вернёт None
    good_payload = {"action": "TEXT", "actionId": 1, "datetime": "2026-04-10T10:00:00", "userId": 1}

    pool = FakePool([
        {"id": 1, "payload": bad_payload},
        {"id": 2, "payload": good_payload},
    ])

    result = await _transform_source(pool, "lms", limit=100, dry_run=False)

    assert result.processed == 2
    assert result.failed == 1
    assert result.done == 1
    assert pool._raw_statuses[1] == "failed"
    assert pool._raw_statuses[2] == "done"


@pytest.mark.asyncio
async def test_transform_user_not_found_marked_failed(monkeypatch):
    """Нет user_uuid → status='failed', pipeline не падает."""
    async def fake_resolve(conn, user_ref):
        return None  # user_not_found

    monkeypatch.setattr(transform_module, "resolve_user_uuid", fake_resolve)

    payload = {"action": "TEXT", "actionId": 1, "datetime": "2026-04-10T10:00:00", "userId": 999}
    pool = FakePool([{"id": 1, "payload": payload}])

    result = await _transform_source(pool, "lms", limit=100, dry_run=False)

    assert result.failed == 1
    assert result.done == 0
    assert pool._raw_statuses[1] == "failed"
