# 🎓 AIST Pilot Bot — Telegram-бот для обучения стажера

Персональный помощник для обучения с AI-генерацией контента.

## ✨ Возможности

- **Онбординг** — бот узнаёт о стажере: область работы, интересы, уровень, цели
- **Персонализация** — контент адаптируется под профиль стажера
- **Расписание** — автоматическая отправка материала в заданное время
- **Прогресс** — отслеживание пройденных тем

## 🚀 Быстрый запуск (15 минут)

### Шаг 1: Создать Telegram-бота (2 мин)

1. Откройте Telegram и найдите [@BotFather](https://t.me/BotFather)
2. Отправьте `/newbot`
3. Введите имя бота: `AIST Pilot`
4. Введите username: `aist_pilot_bot` (придумайте уникальный)
5. **Скопируйте токен** — он выглядит так: `7123456789:AAHxxxxxxxxxxxxxxxxxxxxx`

### Шаг 2: Получить Anthropic API ключ (5 мин)

1. Зайдите на [console.anthropic.com](https://console.anthropic.com)
2. Зарегистрируйтесь или войдите
3. Перейдите в **Settings → API Keys**
4. Нажмите **Create Key**
5. **Скопируйте ключ** — он выглядит так: `sk-ant-api03-xxxxx...`

> 💰 Стоимость: ~$3-5 на 1000 тем (очень дёшево)

### Шаг 3: Запустить на Railway (8 мин)

#### 3.1 Форкните репозиторий

1. Нажмите кнопку **Fork** вверху этой страницы
2. Выберите свой аккаунт GitHub
3. Нажмите **Create fork**

#### 3.2 Разверните на Railway

1. Зайдите на [railway.app](https://railway.app)
2. Нажмите **Login** → войдите через GitHub
3. Нажмите **New Project**
4. Выберите **Deploy from GitHub repo**
5. Найдите и выберите `aist_pilot_bot`
6. Railway начнёт деплой (пока с ошибкой — это нормально)

#### 3.3 Добавьте переменные окружения

1. В Railway нажмите на ваш сервис
2. Перейдите во вкладку **Variables**
3. Добавьте переменные (нажимайте **+ New Variable**):

| Имя | Значение |
|-----|----------|
| `TELEGRAM_BOT_TOKEN` | Токен из Шага 1 |
| `ANTHROPIC_API_KEY` | Ключ из Шага 2 |

4. Нажмите **Deploy** (или подождите автодеплой)

#### 3.4 Готово! 🎉

Через 1-2 минуты бот заработает. Найдите его в Telegram и напишите `/start`

---

## 🖥️ Локальный запуск (для разработки)

```bash
# Клонировать
git clone https://github.com/aisystant/aist_pilot_bot
cd aist_pilot_bot

# Создать виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или: venv\Scripts\activate  # Windows

# Установить зависимости
pip install -r requirements.txt

# Создать .env файл
cp .env.example .env
# Отредактируйте .env и добавьте токены

# Запустить
python bot.py
```

---

## 📱 Как пользоваться ботом

### Команды

| Команда | Описание |
|---------|----------|
| `/start` | Начать (пройти онбординг) |
| `/learn` | Получить тему для изучения |
| `/progress` | Посмотреть прогресс |
| `/profile` | Показать профиль |

### Процесс обучения

```
1. /start → Онбординг (имя, область, интересы, цели)
2. Бот присылает тему в заданное время (или по /learn)
3. Читаешь материал (20 мин)
4. Отвечаешь на вопрос (5 мин)
5. Тема засчитана ✅
6. Повторить со следующей темой
```

---

## ⚙️ Конфигурация

### Переменные окружения

| Переменная | Обязательно | Описание |
|------------|-------------|----------|
| `TELEGRAM_BOT_TOKEN` | ✅ | Токен от @BotFather |
| `ANTHROPIC_API_KEY` | ✅ | Ключ API Anthropic |
| `DIGITAL_TWIN_MCP_URL` | ❌ | URL MCP цифрового двойника |
| `GUIDES_MCP_URL` | ❌ | URL MCP руководств |

### Добавление своих тем

Отредактируйте массив `TOPICS` в `bot.py`:

```python
TOPICS = [
    {
        "id": "my-topic",
        "section": "Мой раздел",
        "subsection": "Мой подраздел",
        "title": "Название темы",
        "main_concept": "ключевое понятие",
        "related_concepts": ["понятие1", "понятие2"]
    },
    # ... добавьте больше тем
]
```

---

## 🔧 Альтернативные способы деплоя

### Render.com (бесплатно)

1. Зайдите на [render.com](https://render.com)
2. New → Web Service → Connect GitHub
3. Выберите репозиторий
4. Настройки:
   - Runtime: Python
   - Build: `pip install -r requirements.txt`
   - Start: `python bot.py`
5. Добавьте Environment Variables
6. Deploy

> ⚠️ Бесплатный тариф засыпает через 15 мин неактивности

### Docker

```bash
docker build -t intern-bot .
docker run -d \
  -e TELEGRAM_BOT_TOKEN=your_token \
  -e ANTHROPIC_API_KEY=your_key \
  intern-bot
```

### VPS (DigitalOcean, Timeweb, etc.)

```bash
# На сервере
git clone https://github.com/aisystant/intern-learning-bot
cd intern-learning-bot
pip install -r requirements.txt

# Создать .env
nano .env

# Запустить через systemd или screen
screen -S bot
python bot.py
# Ctrl+A, D — отключиться от screen
```

---

## 📝 Лицензия

MIT

## 🤝 Контрибьютинг

PR приветствуются!

---

Сделано с ❤️ [Aisystant](https://aisystant.com)

GitHub: [github.com/aisystant/aist_pilot_bot](https://github.com/aisystant/aist_pilot_bot)
